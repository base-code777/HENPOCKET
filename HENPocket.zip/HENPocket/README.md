# HENPocket

Android companion for PS3 HEN and webMAN MOD (`com.henpocket.app`).

## Build
1. Open the `HENPocket` folder in AndroidIDE (or Android Studio).
2. Let Gradle sync. The first build needs internet to download dependencies.
3. Build and install the debug APK.

## Before publishing
Edit `app/src/main/java/com/henpocket/app/data/AppLinks.kt` and set your real GitHub, Ko-fi and PayPal URLs.

## Tabs
- **Home**: auto-discovery, manual IP, live CPU/RSX/fan/storage, Refresh XMB, Reboot, Shutdown
- **Send**: file picker, auto-routing to the right PS3 folder over FTP, live % and MB/s, XMB refresh
- **Split**: split files over 4 GB into .66600, .66601 ... parts on a USB drive
- **Tools**: package cleanup, DNS cheat sheet, About and support

## Notes
- No Sony firmware, keys or game files are included or referenced.
- Parts are 4,294,901,760 bytes (0xFFFF0000), which fits FAT32 and keeps 2048-byte sector alignment.
